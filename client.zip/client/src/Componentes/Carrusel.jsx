import Carousel from 'react-bootstrap/Carousel';


import avion from '../img/ciudad.jpeg'
import landscape from '../img/playa.png'
import calendario from '../img/calendario.png';
import contacto from '../img/contactos.png';
import mascota from '../img/mascota.png'
import '../Estilos/carrusel.css'
function Carouselhome() {
  return (
    <Carousel>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={avion}
          alt="First slide"
        />
        <Carousel.Caption
  style={{
    backgroundColor: "rgba(128, 128, 128, 0.7)", // Color gris con transparencia
    padding: "10px", // Espaciado interno
    borderRadius: "5px", // Esquinas redondeadas
  }}
>
  <h3 style={{ color: "white" }}>VIAJES NACIONALES</h3>
  <p style={{ color: "white" }}>
    Optimizamos tu tiempo, elevamos tu vida: comunicación eficaz para negocios y placer.
  </p>
</Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={landscape}
          alt="second slide"
        />
        <Carousel.Caption>

          <h1>Tips - Usuario</h1>
          <h2> para una mejor experiencia</h2>
          <div class="grid-container">
            <div class="grid-item"><img src={calendario} alt="" /> <p>Agenda desde nuestros formularios</p></div>
            <div class="grid-item"><img src={contacto} alt="" /> <p>Tenemos a los mejores asesores para tus viajes </p></div>
            <div class="grid-item"><img src={mascota} alt="" /> <p>Siempre cuenta con la documentación de tus mascotas.</p></div>
          </div>


        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}

export default Carouselhome;