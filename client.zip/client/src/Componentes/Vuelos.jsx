import React from 'react';
import '../Estilos/Vuelos.css';
import Accordion from 'react-bootstrap/Accordion';
import Button from 'react-bootstrap/Button';
import Dropdown from 'react-bootstrap/Dropdown';
import ListGroup from 'react-bootstrap/ListGroup';


function Vuelos({
  setShowModal,
  loggedIn,
  handleNavLinkClick,
  showPassword,
  togglePasswordVisibility,
  username,
  setUsername,
  password,
  setPassword,
  error,
  setError,
  handleLogin
}) {
  const handleReserveClick = () => {
    if (loggedIn) {
      handleNavLinkClick('Reserva');
    } else {
      setShowModal(true);
    }
  };

  const alertClicked1 = () => {
    alert('Numero para reservas: #########');
  };

  return (
    <div className="App">
      <div className="image">
        <div className="grid-container">
          <div className="grid-item">
            <Accordion flush alwaysOpen>
              <Accordion.Item eventKey="0">
                <Accordion.Header>
                  <img src="https://blog.properati.com.co/wp-content/uploads/2021/02/23-co-cartagena.jpg" alt="Cartagena" className="accordion-image" />
                  <h1>Cartagena</h1>
                </Accordion.Header>
                <Accordion.Body>
                Cartagena de Indias, joya colonial del Caribe colombiano, cautiva con su Ciudad Vieja amurallada, un laberinto de calles empedradas y coloridas casas coloniales que evocan siglos de historia. Sus plazas vibrantes y su rica cultura son un imán para los amantes de la historia y la arquitectura.
                  <br />
                  <Dropdown>
                    <Dropdown.Toggle variant="success" id="dropdown-basic">lugar de partida : precio aproximado</Dropdown.Toggle>
                    <Dropdown.Menu>
                      <Dropdown.Item href="#/action-1">Bogota : 223000 COP</Dropdown.Item>
                      <Dropdown.Item href="#/action-2">B/manga : 250000 COP</Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                  <Button variant="dark" onClick={handleReserveClick}>Reserve ya!</Button>
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="1">
                <Accordion.Header>
                  <img src="https://www.upb.edu.co/es/imagenes/img-sobrelaciudadbucaramanga-cam-1464102319822.jpg" alt="Bucaramanga" className="accordion-image" />
                  <h1>Bucaramanga</h1>
                </Accordion.Header>
                <Accordion.Body>
                Bucaramanga, la Ciudad de los Parques, es un oasis urbano rodeado por la belleza de la Cordillera Oriental. Disfruta de la naturaleza en el Parque del Agua, con sus refrescantes cascadas y fuentes, o pasea por el arbolado Parque García Rovira. En el corazón de la ciudad, la imponente Catedral de la Sagrada Familia y la antigua Capilla de los Dolores son testigos de su rica historia
                  <br />
                  <Dropdown>
                    <Dropdown.Toggle variant="success" id="dropdown-basic">lugar de partida : precio aproximado</Dropdown.Toggle>
                    <Dropdown.Menu>
                      <Dropdown.Item href="#/action-1">Cali : 150000 COP</Dropdown.Item>
                      <Dropdown.Item href="#/action-2">Bogota : 123400 COP</Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                  <Button variant="dark" onClick={handleReserveClick}>Reserve ya!</Button>
                </Accordion.Body>
              </Accordion.Item>
            </Accordion>
          </div>
          <div className="grid-item">
            <Accordion flush alwaysOpen>
              <Accordion.Item eventKey="0">
                <Accordion.Header>
                  <img src="https://www.ul.edu.co/uledhttps://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Panor%C3%A1mica_de_San_Andres.JPG/1280px-Panor%C3%A1mica_de_San_Andres.JPGuco/cache/mod_roksprocket/488cd8edefde50940f7cbae84cefa34f_350_500.jpg" alt="Barranquilla" className="accordion-image" />
                  <h1>San Andres</h1>
                </Accordion.Header>
                <Accordion.Body>
                San Andrés es una isla colombiana ubicada en el Mar Caribe, reconocida mundialmente por sus playas de arena blanca, aguas cristalinas y arrecifes de coral. Forma parte del Archipiélago de San Andrés, Providencia y Santa Catalina, y es un destino turístico muy popular por su belleza natural y su ambiente relajado.
                  <br />
                  <Dropdown>
                    <Dropdown.Toggle variant="success" id="dropdown-basic">lugar de partida : precio aproximado</Dropdown.Toggle>
                    <Dropdown.Menu>
                      <Dropdown.Item href="#/action-1">Bogota : 1268000 COP</Dropdown.Item>
                      <Dropdown.Item href="#/action-2">B/manga : 1123000 COP</Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                  <Button variant="dark" onClick={handleReserveClick}>Reserve ya!</Button>
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="1">
                <Accordion.Header>
                  <img src="https://upload.wikimedia.org/wikipedia/commons/5/56/Noche_en_Medellin.jpg" alt="Medellin" className="accordion-image" />
                  <h1>Medellin</h1>
                </Accordion.Header>
                <Accordion.Body>
                  Medellín es la capital de la provincia montañosa de Antioquia en Colombia. Es apodada la "Ciudad de la eterna primavera" por su clima templado y alberga la famosa Feria de las Flores anual. El moderno Metrocable conecta la ciudad con los barrios circundantes y tiene vistas del Valle de Aburrá que se encuentra debajo. Las esculturas de Fernando Botero decoran la Plaza Botero en el centro de la ciudad, mientras que el Museo de Antioquia exhibe más obras del artista colombiano.
                  <br />
                  <Dropdown>
                    <Dropdown.Toggle variant="success" id="dropdown-basic">lugar de partida : precio aproximado</Dropdown.Toggle>
                    <Dropdown.Menu>
                      <Dropdown.Item href="#/action-1">Bogota : 1505000 COP</Dropdown.Item>
                      <Dropdown.Item href="#/action-2">B/manga : 1703000 COP</Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                  <Button variant="dark" onClick={handleReserveClick}>Reserve ya!</Button>
                </Accordion.Body>
              </Accordion.Item>
            </Accordion>
          </div>
        </div>
        <div className="grid-container2">
          <div className="item1grid2">
            <ListGroup>
              <ListGroup.Item action href="#link1" disabled>
                <h2>Cali</h2> 1120500 COP
              </ListGroup.Item>
              <ListGroup.Item action href="#link2" disabled>
                <h2>Bogota</h2> 1450800 COP
              </ListGroup.Item>
              <ListGroup.Item onClick={alertClicked1}>
                Reserva atravez de nuestras lineas telefonicas
              </ListGroup.Item>
            </ListGroup>
          </div>
          <ListGroup>
            <ListGroup.Item action href="#link1" disabled>
              <h2>Barranquilla</h2> 2150500 COP
            </ListGroup.Item>
            <ListGroup.Item action href="#link2" disabled>
              <h2>Villavicensio</h2> 1950500 COP
            </ListGroup.Item>
            <ListGroup.Item action onClick={handleReserveClick}>
              Reserva ya en linea
            </ListGroup.Item>
          </ListGroup>
        </div>
      </div>
    </div>
  );
}

export default Vuelos;